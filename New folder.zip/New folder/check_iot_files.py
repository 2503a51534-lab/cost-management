
import os
from iot_config import (
    CERTIFICATE_PATH,
    PRIVATE_KEY_PATH,
    ROOT_CA_PATH,
    IOT_ENDPOINT
)

files = {
    "Device certificate": CERTIFICATE_PATH,
    "Private key": PRIVATE_KEY_PATH,
    "Root CA": ROOT_CA_PATH
}

print("Checking AWS IoT files...\n")

for name, path in files.items():
    if os.path.isfile(path):
        print(f"FOUND: {name}")
    else:
        print(f"MISSING: {name} - {path}")

if IOT_ENDPOINT and "PASTE_YOUR_ENDPOINT_HERE" not in IOT_ENDPOINT:
    print("\nEndpoint configured")
else:
    print("\nEndpoint missing")
