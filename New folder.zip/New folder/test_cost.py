
import boto3
from datetime import date, timedelta

try:
    client = boto3.client("ce", region_name="us-east-1")

    end = date.today()
    start = end - timedelta(days=7)

    result = client.get_cost_and_usage(
        TimePeriod={
            "Start": start.isoformat(),
            "End": end.isoformat()
        },
        Granularity="DAILY",
        Metrics=["UnblendedCost"]
    )

    print("COST EXPLORER ACCESS SUCCESSFUL")

    for day in result["ResultsByTime"]:
        amount = day["Total"]["UnblendedCost"]["Amount"]
        unit = day["Total"]["UnblendedCost"]["Unit"]
        print(day["TimePeriod"]["Start"], amount, unit)

except Exception as error:
    print("COST EXPLORER ACCESS FAILED")
    print(error)
